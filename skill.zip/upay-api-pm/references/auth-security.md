# Authentication, Security, Environments & Connectivity

## Environments

- Sandbox base URL: `https://openapi.upay-test.best`
- Production base URL/credentials are supplied during production onboarding.
- Real card transactions cannot be performed in Dev; use simulator endpoints.

## Standard request headers

- `X-UPA-APIKEY`
- `X-UPA-REQUESTID`
- `X-UPA-TIMESTAMP`
- `X-UPA-SIGN`

`X-UPA-*` is correct. `X-UPAY-*` references are documentation typos.

## Signature

- Validity window: 60 seconds.
- Raw string: `METHOD|URI|TIMESTAMP|REQUEST_ID|SIGN_PARAM`
- Sort parameters ascending by key.
- Join as `key=value` using `&`.
- Nested objects: sort keys and compact-serialize.
- Sign with HMAC-SHA256 using Secret Key, then Base64.
- Optional empty/null/empty-array canonicalization is not universally defined; omit optional empty fields unless the exact endpoint contract says otherwise.

## JWE

Use the API List `Data encrypted` flag:

- Yes = request uses JWE.
- No = plain JSON.
- Signature is still required unless explicitly exempted.

JWE header:

- `alg`: RSA-OAEP-256
- `enc`: A128GCM
- `typ`: JOSE
- `zip`: DEF

Encrypted outer body:

```json
{"payload":"..."}
```

Direction:

- Merchant encrypts request with Platform Public Key.
- UPay decrypts with platform private key.
- UPay encrypts response with merchant public key.
- Merchant decrypts with merchant private key.

`kid` derivation: RSA public key DER SPKI -> SHA-256 -> Base64URL without padding -> uppercase.

Confirmed example: `/api/v1/account/list` does **not** require JWE; it expects plain JSON plus signature.

## IP / callback configuration

Always distinguish three controls.

### UPay webhook source IPs

Production:

- `16.163.46.214`
- `16.163.68.119`
- `16.163.223.198`

Sandbox:

- `43.199.161.111`

These are UPay outbound webhook source IPs. Merchants can allowlist them on inbound firewall/WAF and should still verify `X-UPA-SIGN`.

### Merchant callback URL

- One callback URL per merchant.
- New callback URL must be submitted to UPay for configuration/whitelisting before use.
- Comma-separated multiple callback URLs are not supported.
- Merchants needing multiple downstream destinations should receive once and fan out internally.

### Merchant outbound/source IP

A confirmed Sandbox merchant setup did not require UPay-side allowlisting of the merchant's outbound IP. Do not generalize this to every production merchant without checking current configuration.

## Rate limits

- 10 requests/second
- 600 requests/minute

Use webhooks as the primary state-change mechanism; use queries for reconciliation/recovery rather than aggressive polling.

## SLA/support

- Uptime SLA: 99.99%.
- Support/incident handling target: generally within ~24h depending severity/urgency.

## Connectivity triage

`TypeError: fetch failed` with no HTTP response usually means transport/connectivity before UPay business processing. Ask for:

- exact timestamp + timezone;
- requestId;
- source public IP;
- full error/stack including `cause`;
- curl reproduction from same host.
