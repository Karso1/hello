# Remote Host Authorization & Card Webhooks

## Shared Model vs Remote Host Authorization

They are separate capabilities.

Without Remote Host Authorization, UPay makes authorization decisions using its own pre-checks.

With Remote Host Authorization enabled:

1. UPay performs its pre-checks first.
2. Passing transactions trigger `CC_AUTHORIZATION`.
3. Merchant must answer within 2.5 seconds.
4. Response: HTTP 200 with exact `approve` or `decline`.

`CC_AUTHORIZATION` is the authorization request itself, not an after-the-fact notification.

## CC_AUTHORIZATION payload

Confirmed detail fields:

- `cardId`
- `cardNumber` (last 4)
- `amount`
- `currency`
- `merchantMcc`
- `transactionId`
- `authorizationId`
- `transactionChannel`

Outer fields include:

- `event`
- `trace`
- `orderNo`
- `timestamp`

## Amount

`CC_AUTHORIZATION.detail.amount` is the total USD settlement authorization amount and already includes applicable fees such as FX, ATM and transaction fees.

Do not add `detail.fee` again on top of the authorization amount.

Detailed fee breakdown is provided later in transaction webhook data.

## transactionChannel

Confirmed values:

- ATM
- POS
- E-COMMERCE
- COF
- UNKNOWN

## Pre-checks

UPay checks card limit before `CC_AUTHORIZATION`.

It can also decline before merchant authorization for insufficient Card Consumption Account balance or other controls such as MCC/country/currency/card restrictions.

A pre-check decline may still produce a failed `CC_CONSUME`/transaction lifecycle event.

## Timeout and decline

Merchant response window: 2.5 seconds.

If no valid response arrives within the window, the transaction fails and the corresponding failed transaction notification is triggered.

Merchant `decline` also produces the failed transaction lifecycle notification.

Confirmed support wording for the relevant failure reason: `error in service`.

Late `approve` after the timeout does not revive the transaction.

## CC_AUTHORIZATION retry behavior

**Confirmed latest internal rule:** `CC_AUTHORIZATION` is pushed only once. It is **not** retried every 3 seconds and does not follow the normal “5 attempts” webhook policy.

After approval, UPay does not repeat `CC_AUTHORIZATION`. The transaction continues through the normal lifecycle, e.g. `CC_CONSUME` or `CC_WITHDRAW_CASH`.

This rule overrides older/public indications that may label the event as repeatable.

## Ordinary webhook delivery

Normal webhook success requirement:

- HTTP 200
- exact plain text `SUCCESS`
- within 5 seconds

Normal webhook failure retry:

- every 3 seconds;
- up to 5 failed attempts;
- then automatic retries stop.

No merchant self-service replay mechanism is confirmed.

Use query/bill APIs for reconciliation.

## Webhook signature

Headers include:

- `X-UPA-REQUESTID`
- `X-UPA-TIMESTAMP`
- `X-UPA-SIGN`

Raw signing string:

`event|timestamp|body`

- event: from decrypted webhook data;
- timestamp: `X-UPA-TIMESTAMP` (13-digit millisecond timestamp);
- body: exact original encrypted/raw HTTP body.

Sign with HMAC-SHA256 using Secret Key, then Base64 and compare to `X-UPA-SIGN`.

Do not trim/reformat/re-serialize the raw body before verification.

Recommended flow:

1. Read exact raw body.
2. Decrypt with merchant private key to obtain event.
3. Build signing string using event + header timestamp + original raw body.
4. HMAC-SHA256 + Base64.
5. Compare `X-UPA-SIGN`.
6. Process business logic.
7. Return HTTP 200 + `SUCCESS` within 5s.

## Idempotency

For transaction webhooks such as:

- CC_CONSUME
- CC_REFUND
- CC_WITHDRAW_CASH
- CC_REDEEM
- CC_MANAGEMENT_FEE
- CC_RECHARGE

use `X-UPA-REQUESTID` for duplicate callback handling.

Do not dedupe solely by `transactionId` because valid lifecycle records can share it.

Confirmed internal behavior: manual re-push uses the original `X-UPA-REQUESTID`.

## Status mapping

Confirmed statuses:

- 2 = Failed
- 4 = Posted
- 5 = Unposted
- 7 = Canceled

### CC_CONSUME

- 5 = authorization/pre-authorization, pending settlement
- 4 = settlement completed
- 7 = reversal/cancel
- 2 = decline/failure

Typical success: `5 -> 4`
Typical reversal: `5 -> 7`

### CC_WITHDRAW_CASH

- 5 = pre-authorization/pending settlement
- 4 = settled
- 7 = reversal
- 2 = decline/failure

### CC_REFUND

Latest confirmed rule: only push `status=4 (POSTED)` for completed refund.

## Bypass cases

Rare cases can bypass merchant host authorization, including offline, Visa Stand-In, or direct-settlement flows.

Do not promise 100% of economic changes will have prior merchant approval. Reconciliation must still accept later settlement/adjustment events.
