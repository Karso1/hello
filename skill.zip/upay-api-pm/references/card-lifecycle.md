# Card Issuance, Status, Activation, PIN & Wallet Binding

## Card products and card IDs

Product/Card IDs in the available-card list identify card products. Once issued, each card receives its own unique `cardId`.

One `cardId` corresponds to one issued card/PAN in the normal model.

A user account can apply for one card of the same card product. Multiple cards of the same product require separate customer accounts/KYC.

Confirmed overall maximum in the referenced program: 4 cards total = 2 virtual + 2 physical, each a different card type/product.

After deactivation, the customer can apply again for the same type.

## Virtual vs physical issuance

Virtual cards:

- automatically active after approval;
- no activation code;
- no Card Activation flow.

Physical cards:

- `Card Making` after issuance;
- then `Pending Activation` after shipment/production stage;
- require activation code and activation flow;
- expiry date/CVV cannot be retrieved while still Pending Activation; retrieve after successful activation.

Only physical cards need an activation code.

## CS_APPROVED

Each card triggers `CS_APPROVED` only once.

Physical Card:

- `CS_APPROVED` fires when the card becomes `Pending Activation`.

Virtual Card:

- `CS_APPROVED` fires when the card becomes `Normal`.

`CSC_STATUS_CHANGE status=1` does **not** replace an expected `CS_APPROVED` notification.

## Physical-card sandbox review

Physical cards require manual review.

In Sandbox there is no automatic physical-card review process. For physical-card sandbox testing, merchant should inform UPay in advance so review can be arranged.

## Activation flow

Internal guide confirms Card Activation applies only to physical cards.

1. `/api/v1/card/list` — get physical-card `cardId` by customer number.
2. `/api/v1/card/info` — retrieve registered-card details.
3. `/api/v1/card/query/activate/code` — query activation code using `cardId` + customer number.
4. Activate Card API — complete activation.

## Card-info status

`POST /api/v1/card/info`

Card status field: `data.status`.

Confirmed card-status mapping used in support:

- `1` Normal
- `2` Pending Activation
- `3` Frozen
- `4` Locked
- `5` Deactivated
- `13` Rejected

Status changes are also pushed by `CSC_STATUS_CHANGE.detail.status`.

Example response shape:

```json
{
  "code": 0,
  "msg": "string",
  "success": true,
  "ts": 0,
  "data": {
    "cardId": "string",
    "status": 0,
    "openCardTime": "string",
    "openCardOrderNo": "string",
    "customerNo": "string",
    "customerGroupNo": "string",
    "cardName": "string",
    "cardBin": "string",
    "type": 0,
    "organization": "string",
    "cardCurrency": "string",
    "rechargeCurrency": "string",
    "cardNumber": "string",
    "cvv": "string",
    "expiryDate": "string",
    "availableBalance": 0,
    "freezeAmount": 0,
    "registerCardId": "string",
    "mode": 0,
    "thirdOrderNo": "string",
    "issuanceTime": "string"
  }
}
```

## CE_EVENT

`CE_EVENT` is triggered by UPay when a card is frozen by UPay or when there is a card-related issue.

Merchant cannot manually trigger `CE_EVENT` for testing.

For testing, use the Lock / Unlock Card API instead.

## PIN / transaction password

Transaction password = card transaction PIN, not API password/login password/3DS OTP.

UPay PIN length: 6 digits.

Used for transactions requiring PIN, especially ATM where supported.

Query setting mode:

`/api/v1/card/trade/password/setting/mode/query`

- Mode 1: certain Platinum/Precious API-setting flow.
- Mode 2: Premier H5/IFrame flow; URL is 10-minute single-use. Blank page can indicate success; monitor H5 title `Success`.

IFrame language confirmed/documented: `en-US`, `zh-CN`.

## 3DS

Types seen:

- `3DS_OTP`
- `3DS_Confirm`
- `3DS_Confirmation Link`

Premier OTP: 3 min.
Platinum OTP + Confirm: confirm within 3 min.
Precious confirmation link: 5 min.
Apple/Google/PayPal binding SMS OTP: 3 min.

3DS method is issuer/product configured.

## Apple Pay / tokenization

A tokenized wallet DPAN last 4 can differ from the physical/virtual card FPAN last 4. This is normal and does not mean one `cardId` maps to multiple normal PANs.

## Physical-card standard dimensions

- Width: 3.370 in / 85.60 mm
- Height: 2.125 in / 53.98 mm
- Thickness: 0.030 in / 0.76 mm / 30 mils
