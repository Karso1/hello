# Customer, Registration, KYC, Phone & Address

## Sandbox data quality

Sandbox card application still expects real/valid data. Do not use random fake data to force negative KYC unless UPay supplies an official negative test case.

Primary credential types include:

- National ID
- Passport
- Residence Permit
- Driver's License

Confirmed flow does not require facial recognition for the referenced setup.

Email:

- valid/non-random;
- <= 50 characters.

Phone:

- valid international phone;
- reachable/validatable by the configured third-party provider;
- phone uniqueness is strictly enforced by the channel;
- the same phone-number validation rules are configured in Sandbox and Production;
- this uniqueness requirement cannot be bypassed/relaxed.

When testing, use a valid number in the correct format that can be validated by the third-party provider.

## `/customer/update` and code 10011

`10011` means phone number already in use.

If `/api/v1/customer/update` returns 10011 while the merchant believes the same customer is submitting its own existing phone number, collect:

- requestId;
- customerNo(s);
- masked phone/globalCode;
- exact environment.

Check backend uniqueness logic and provider-side normalized phone records rather than assuming Dashboard visibility proves no duplicate exists.

Phone-format errors have separate codes (for example 10093/10094 in the public code list), so 10011 should be treated as uniqueness/usage validation rather than simple formatting.

## Address / area list

If `/api/v1/common/area/list` has no city child entries for a province/state, `cityId` can be left blank.

However, submitted address fields must agree:

- selected `provinceId` must match the actual address;
- detailed address should contain a real complete English address;
- postal code should correspond to the actual address;
- do not select Sirdaryo while detailed address says Andijan/Namangan, etc.

Recommended detailed-address components:

`Unit / Building / Street / Area / Country / Postal Code`

A province-only string such as `Andijan Region, Uzbekistan` is not a complete detailed address for physical-card issuance/address checks.

Ukraine billing-address restriction is confirmed for the relevant card program and cannot be removed.

## KYC errors

### 10186

Existing Basic/Primary KYC record. Only one basic authentication type is allowed. Repeating `/customer/kyc/submit` will keep failing until the prior state is handled/reset through the supported process.

No generic public reset/delete Basic-KYC endpoint is confirmed.

### 10187

`The country where the customer's KYC authentication is located is restricted.`

This can occur during card-registration pre-validation. If rejected before order creation, there may be no operation order/webhook.

A general allowed-country list does not guarantee every issuer/BIN/card product accepts that country.

## Old vs new KYC result model

`/api/v1/customer/kyc/progress` = process / credential-level progress, **not** the final overall KYC source of truth.

New overall result system:

- Webhook: `KS_AUTH_RESULT`
- Active query: `/api/v1/customer/authentication/result`

`KS_AUTH_RESULT.status`:

- 1 Approved
- 2 Rejected
- 3 Pending
- 4 Unverified

Recommended architecture:

`KS_AUTH_RESULT` triggers state change -> call `/customer/authentication/result` -> use the latest overall result and document/reason detail.

The active query can include `authDocumentsInfo[]` with credential/document detail.

Rare manual review can update a prior result later; systems should accept later result updates.
