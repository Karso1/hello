# Simulator, Errors & Debugging Cases

## Simulator

Real transactions cannot be performed in Dev.

Authorization simulator:

`POST /api/v1/simulate/authorisation`

Ensure sufficient balance/consumable amount before simulation.

Premier limitation:

- supports authorization / UNPOSTED simulation;
- does not support POSTED/settlement simulation in the current simulator;
- settlement simulation can return `10174` Action/Operation not supported.

## Common errors / cases

### 401 on `/api/v1/acquirer/pay`

Confirmed case: merchant had Card API permission only, not Acquirer permission. Root cause was module permission, not signature/timestamp.

### 1005 Signature error on `/api/v1/account/list`

Known case: merchant sent JWE outer payload while signing `accountType=1`. `/account/list` should use plain JSON + signature.

### 1006 Configuration error on `/api/v1/card/available/list`

Request reached API. Check production product/permission/credential configuration. Do not claim a more specific root cause without backend evidence.

### 10163

Requested consumable-amount increase exceeds allocatable Shared position/Card Consumption Account.

### 10174

Operation not supported. Common when attempting Premier settlement simulation.

### 10186

Existing Basic/Primary KYC record.

### 10187

KYC country restricted for the card issuance configuration.

### 10175

`thirdOrderNo` already exists / duplicate order validation.

### CARD_LIMIT_EXCEEDED with visible limit above amount

Do not explain from visible numbers alone. Inspect backend actual remaining consumable amount and all applied limits/risk controls.

## Wallet `/api/v1/wallet/apply` returns HTTP 403

Do not automatically say Wallet permission is disabled if merchant admin permissions show Wallet enabled.

403 looks like gateway/access control before wallet business validation, while wallet-specific “not granted” may use a business code.

Debug using same API Key + same source server/IP:

- `/api/v1/wallet/info`
- `/api/v1/wallet/address/deposit/list`
- `/api/v1/account/list`

Interpretation:

- all return 403 -> check API key/environment/global permission/IP/gateway mapping;
- other endpoints work and only `/wallet/apply` is 403 -> check endpoint route permission/config/JWE key/kid/synchronization.

Existing deposit addresses:

`POST /api/v1/wallet/address/deposit/list`

Create/apply deposit address:

`POST /api/v1/wallet/apply`

Supported wallet/coin/chain info:

`POST /api/v1/wallet/info`

## Final Review Failed / registration issues

- `Final Review Failed` = final review rejected; ask for order ID to inspect specific reason.
- `Abnormal Card Registration` = incomplete/invalid required data, e.g. postal code or batch field.
- `Service Deviation` = temporary network/API/service sequencing issue; avoid repeated submissions while a prior request may still be processing.

## Webhook/content type incident

A confirmed missing-webhook case was caused by invalid JSON/body handling while `Content-Type: application/json` was used. UPay corrected that case to `text/plain` and re-pushed.

Do not blindly force every webhook raw body through JSON parsing before signature/decryption steps.

## Broker callback URL incident

Merchant changed domains and received some transaction events but not expected authorization events. Root cause: Broker callback URL configured incorrectly. Correcting the URL resolved it.
