# Product, Commercial, Risk, Disputes & Operational Facts

## Product positioning

UPay is not a merchant-rebrandable SaaS hosted frontend/backend.

UPay provides:

- APIs
- Dashboard/Admin Panel
- Sandbox/production access

Merchant builds and hosts its own customer-facing frontend/backend.

No official SDK or UI component library is currently confirmed; integrate directly with APIs.

## Card type / cloud-service use

UPay Visa cards are Debit Cards, not Credit Cards.

Current cards can be used for cloud-service purchases, but acceptance by a specific cloud provider remains subject to that provider's payment/risk rules.

Do not promise that a new card bypasses cloud-provider BIN restrictions or guarantees free-credit/promotional eligibility.

Safe wording: no additional hidden UPay-specific risk identified, but third-party acceptance, account registration, promotional eligibility, and provider risk controls remain provider-controlled.

## Issuance volume / account rule

- Merchant total issuance has no fixed upper limit.
- One user account can apply for only one card of the same card product.
- Multiple same-product cards require multiple user accounts/KYC.
- Programmatic new-card generation is supported; bulk automation specifics should follow the approved technical flow.

## Current card price

- Virtual: 3 USDT/card
- Physical: 35 USDT/card

## Physical-card standard size

- 85.60 mm x 53.98 mm
- thickness 0.76 mm (30 mil)

## Risk controls

### ATM limits

Platinum:

- daily 3k
- monthly 10k
- yearly 100k
- max 3/day, 30/month
- Mainland China ATM unsupported

Premier:

- daily 3k
- monthly 20k
- max 5/day, 30/month

### High-frequency / lock examples

- same cardholder >=30 tx / 30 min may lock/review;
- same merchant >=30 tx same card / 1h may lock/review;
- repeated wrong card data/PIN can lock;
- 30 consecutive failures can lock/investigate.

Platinum automatic freeze examples:

- 3 incorrect CVV within 1h
- 3 incorrect expiry within 1h
- 3 incorrect transaction PIN attempts

Do not say “3 insufficient-funds declines” causes this freeze.

Settlement shortfall can lock until debt is cleared; causes can include FX fluctuation, merchant amount adjustment, offline transaction.

### MCC blacklist

Confirmed list for Platinum & Premier:

`4829, 5542, 6010, 6012, 6051, 6540, 7273, 7995, 9223`

List can change.

`merchantMcc` enables category-level controls, not reliable unique-merchant blocking.

Card cancellation fee: 1 USDT/card.

## Careem / Apple Pay observation

Observed repeated pattern: Careem + Apple Pay + UPay card -> immediate pre-authorization cancel/reversal.

UPay has no direct Careem-specific restriction confirmed.

Safe external wording: observed behavior suggests merchant-side acceptance/risk controls may be rejecting or reversing these transactions, potentially related to BIN/card product/tokenized Apple Pay transactions. Recommend checking with Careem/provider.

Do not state “Careem blocks UPay” as a confirmed fact unless merchant/provider confirms it.

## Consumer dispute / chargeback

For paid goods/services not received, wrong/defective goods, or similar consumer merchandise/service issue:

1. customer first contacts merchant and requests refund/resolution;
2. if merchant refuses refund or does not handle the request, then proceed with dispute process;
3. this fits Consumer dispute reason category.

Do not instruct the customer to dispute first without attempting merchant resolution for this scenario.

## Physical-card Sandbox manual review

Physical cards require manual review. Sandbox has no automatic physical-card review, so testing parties should notify UPay in advance.
