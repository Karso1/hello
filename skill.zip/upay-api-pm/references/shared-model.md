# Merchant Scope, Shared Model, Accounts & Limits

## Merchant integration scope

Current card-business integration normally uses:

- Public API
- Merchant API
- Card API
- Card Webhook

Wallet, Acquirer, and Outlay APIs are separate modules and require separate need/permission.

One merchant currently maps to:

- one API Key;
- one Secret Key;
- one merchant public-key setup;
- one webhook callback URL.

If a merchant serves multiple downstream systems, the merchant implements its own routing/fan-out.

Calling `/api/v1/acquirer/pay` without Acquirer permission returns 401 Unauthorized. A confirmed case was permission-related, not signature/timestamp-related.

## Shared Model core behavior

- Individual cards do **not** require separate recharge.
- Card spending is funded from the merchant Card Consumption Account.
- Merchant still sets a per-card consumable/spending limit.
- At authorization time UPay checks card limit, Card Consumption Account available balance, and other controls.

## Accounts and transfer

Relevant accounts:

- Crypto Account
- Card Consumption Account

Before transactions, transfer funds:

`Crypto Account -> Card Consumption Account`

API: `/api/v1/account/fund/transfer/submit`

Confirmed Shared Model transfer is one-way; no reverse transfer.

Endpoint-specific `from/to` values in fund transfer:

- `1` = Crypto-to-Crypto
- `2` = Card Consumption

Do not confuse with `/account/list.accountType`:

- `1` = Crypto-to-Crypto
- `2` = Fiat
- `3` = Card Consumption

## Merchant asset query

`POST /api/v1/merchant/asset`

Use to query merchant master-account assets, including wallet crypto assets and Card Consumption Account assets.

## Per-card consumable amount

API:

`POST /api/v1/card/consume/amount/auth`

- `type=1` increase
- `type=2` decrease
- Amount is USD.
- No independent freeze-only API for Shared Model. Merchant-side temporary hold should be maintained in merchant ledger/accounting.

Important: allocation is not independent of the bucket. Increasing per-card consumable amount checks the underlying allocatable Shared position/Card Consumption Account.

Error `10163`:

`The increase in consume amount cannot exceed the total consumable amount of the position`

Meaning: requested increase exceeds currently allocatable Shared position.

There is no dedicated merchant-level API confirmed to return the total sum of limits allocated across all cards. `/card/consume/amount/auth/list` is adjustment history, not an aggregate-limit endpoint.

## thirdOrderNo / idempotency

`thirdOrderNo` is used for duplicate/idempotency validation on `/card/consume/amount/auth`.

Confirmed operational rules:

- use a unique `thirdOrderNo` per independent adjustment;
- reusing the same value triggers duplicate validation and does not repeat the adjustment;
- UPay performs validation rather than maintaining a user-facing “expiry period” for the idempotency key;
- successful API response means the adjusted consumable amount is effective immediately;
- query operation history with `/api/v1/card/consume/amount/auth/list`.

Relevant error:

- `10175` = The third order number already exists.

Same-card adjustments:

- processed in order;
- do not submit two adjustments concurrently for the same card;
- concurrent duplicate requests trigger validation/error.

If current permitted amount is insufficient for the requested decrease, reject the operation as a whole; do not partially decrease and do not create a negative balance.

Relevant errors include:

- `10161` The reduction of consume amount cannot exceed the authorized total amount.
- `10162` The reduced consume amount cannot be less than the remaining consumable total amount on the card.
- `10163` Increase exceeds total consumable position.
- `10164` Authorization for consume amount failed.

## Fees / issuance cost

Shared transaction and FX fees are deducted from Card Consumption Account.

Confirmed example: USD100 + 2% FX + 1% transaction fee = `(100 + 2) * 1.01 = 103.02 USDT`.

Minimum transaction fee: 0.01 USDT. Fee rounds **up** to 2 decimals.

Card issuance fee is deducted from Crypto Account, not Card Consumption Account.

Current commercial card cost:

- Virtual card: 3 USDT/card
- Physical card: 35 USDT/card

## Transaction limit note

For the current “尊享卡” product:

- normal single-transaction maximum: 16,000 USD;
- special users can be adjusted to 80,000 USD through UPay configuration.
