# Transactions, Settlement, Refunds, IDs & Reconciliation

## Identifier meanings

- `transactionId`: transaction/lifecycle identifier. Same lifecycle can share it across multiple records/statuses.
- `orderNo`: specific order/record identifier. Different orderNo values can still belong to the same transactionId lifecycle.
- `trace`: technical chain tracing identifier.
- `authorizationId`: authorization-stage identifier.
- `X-UPA-REQUESTID`: webhook/request idempotency identifier for applicable events.

Do not use `transactionId` alone as a universal deduplication key.

Persist at least:

- event
- status
- orderNo
- transactionId
- X-UPA-REQUESTID

## Refund association

`CC_REFUND.detail.amount` is the amount of **that refund**, not cumulative refund amount.

Example:

- first partial refund 300 -> amount 300
- second partial refund 200 -> amount 200

Confirmed rules:

- multiple partial refunds are supported;
- cumulative refund is controlled so it does not exceed the original deduction;
- after partial refunds, the remaining refundable amount can be refunded.

If a refund is a separate transaction, it can have a new `transactionId`.

For a new refund transactionId, use `detail.cardId` to locate the card and inspect that card's transaction history, then correlate amount/time/order information.

Consumer purchase refund = `CC_REFUND`.
ATM authorization reversal/cancel = `CC_WITHDRAW_CASH status=7` rather than the exact same refund flow.

## Partial reversal examples

Confirmed pattern: original and partial reversal can have different `orderNo` but the same `transactionId`.

A small INCOME/reversal record with the same `transactionId` can be a partial release, not a new charge.

## Amount fields

In card transaction webhooks:

- `detail.amount` + `detail.currency` = UPay settlement/accounting amount.
- `detail.originalAmount` + `detail.originalCurrency` = original merchant transaction amount/currency.

When the card is used in a non-USD purchase, accounting should use the USD settlement `amount` for USD ledger purposes and retain originalAmount/originalCurrency for reference.

## Precision

Confirmed:

- Card Bill amounts: 4 decimal places.
- Wallet amounts: 2 decimal places.

Preserve source precision during reconciliation; do not assume the two systems use the same precision.

## Settlement timing

External communication:

- usually 1–3 days;
- some cases can take up to 14 days;
- no fixed guaranteed timeframe.

Late provider settlements/adjustments must still be processed even after a merchant's internal hold timeout.

Later updates can cause additional debit or refund.

Do **not** state 30 days as the standard settlement or webhook SLA.

## Authorization vs final amount

Authorization amount can differ from final settlement due to:

- FX change;
- merchant amount adjustment;
- tip;
- offline transaction;
- provider adjustment;
- fee finalization timing.

Do not assume a larger final amount will always trigger a second `CC_AUTHORIZATION`.

Store authorization amount and final settled amount separately.

## Card deactivation / returned funds

Card Bill:

- `transactionType=9` = Deactivate / Amount Returned.

Wallet/account ledger:

`POST /api/v1/account/ledger/list`

- `accountType=1` Crypto-to-Crypto
- `transactionType=67` card cancellation / refund of remaining balance

Current limitation: no reliable common reference is confirmed between `CSC_STATUS_CHANGE.orderNo` and the wallet-ledger refund; wallet record may lack cardId.

## Duplicate posting incident triage

If one authorization is linked to two different posting/bill records with the same amount, do **not** immediately call it a duplicate webhook. Distinguish:

1. upstream provider sent duplicate clearing/presentment;
2. UPay clearing ingestion/posting job processed the same clearing item twice;
3. merchant only received duplicate notifications for one underlying posting.

Check:

- provider clearing reference / ARN / RRN / STAN where available;
- posting/bill IDs;
- authorization parent/reference;
- exact batch time window;
- whether later reversal exists;
- UPay ingestion/job logs.

Do not have support agents manually compensate many cases until the reversal/credit strategy is confirmed, or later provider reversal can cause double compensation.
